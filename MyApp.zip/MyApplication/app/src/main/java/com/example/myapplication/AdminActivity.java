
package com.example.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AdminActivity extends AppCompatActivity {

    private EditText flightNumberEditText, fromEditText, toEditText, dateEditText, priceEditText, boardingTimeEditText, deboardingTimeEditText;
    private DatabaseReference dbRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        flightNumberEditText = findViewById(R.id.flightNumberEditText);
        fromEditText = findViewById(R.id.fromEditText);
        toEditText = findViewById(R.id.toEditText);
        dateEditText = findViewById(R.id.dateEditText);
        priceEditText = findViewById(R.id.priceEditText);
        boardingTimeEditText = findViewById(R.id.boardingTimeEditText);
        deboardingTimeEditText = findViewById(R.id.deboardingTimeEditText);
        Button addFlightButton = findViewById(R.id.addFlightButton);

        dbRef = FirebaseDatabase.getInstance().getReference("flights");

        addFlightButton.setOnClickListener(v -> addFlight());
    }

    private void addFlight() {
        String flightNumber = flightNumberEditText.getText().toString().trim();
        String from = fromEditText.getText().toString().trim();
        String to = toEditText.getText().toString().trim();
        String date = dateEditText.getText().toString().trim();
        String price = priceEditText.getText().toString().trim();
        String boardingTime = boardingTimeEditText.getText().toString().trim();
        String deboardingTime = deboardingTimeEditText.getText().toString().trim();

        if (flightNumber.isEmpty() || from.isEmpty() || to.isEmpty() || date.isEmpty() || price.isEmpty() || boardingTime.isEmpty() || deboardingTime.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        Flight flight = new Flight(flightNumber, from, to, date, price, boardingTime, deboardingTime);
        dbRef.child(flightNumber).setValue(flight)
                .addOnSuccessListener(aVoid -> Toast.makeText(this, "Flight added successfully", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e -> Toast.makeText(this, "Failed to add flight", Toast.LENGTH_SHORT).show());
    }
}

