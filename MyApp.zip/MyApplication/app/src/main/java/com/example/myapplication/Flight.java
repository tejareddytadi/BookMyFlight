/*
package com.example.myapplication;

public class Flight {
    public String flightNumber;
    public String from;
    public String to;
    public String date;
    public String price;

    public Flight() {
        // Default constructor required for Firebase
    }

    public Flight(String flightNumber, String from, String to, String date, String price) {
        this.flightNumber = flightNumber;
        this.from = from;
        this.to = to;
        this.date = date;
        this.price = price;
    }
}*/
package com.example.myapplication;

public class Flight {
    public String flightNumber;
    public String from;
    public String to;
    public String date;
    public String price;
    public String boardingTime;
    public String deboardingTime;

    public Flight() {
        // Default constructor required for Firebase
    }

    public Flight(String flightNumber, String from, String to, String date, String price, String boardingTime, String deboardingTime) {
        this.flightNumber = flightNumber;
        this.from = from;
        this.to = to;
        this.date = date;
        this.price = price;
        this.boardingTime = boardingTime;
        this.deboardingTime = deboardingTime;
    }
}

