/*package com.example.myapplication;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.HashMap;
import java.util.Map;

public class FlightDetailsActivity extends AppCompatActivity {

    private TextView flightDetailsTextView;
    private Button bookFlightButton;
    private DatabaseReference dbRef;
    private String flightNumber, from, to, date, price;
    private static final String TAG = "FlightDetailsActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flight_details);

        flightDetailsTextView = findViewById(R.id.flightDetailsTextView);
        bookFlightButton = findViewById(R.id.bookFlightButton);

        dbRef = FirebaseDatabase.getInstance().getReference("bookings");

        // Get flight details from intent
        flightNumber = getIntent().getStringExtra("flightNumber");
        from = getIntent().getStringExtra("from");
        to = getIntent().getStringExtra("to");
        date = getIntent().getStringExtra("date");
        price = getIntent().getStringExtra("price");

        Log.d(TAG, "Flight details received: " + flightNumber + ", " + from + ", " + to + ", " + date + ", " + price);

        if (flightNumber == null || from == null || to == null || date == null || price == null) {
            Toast.makeText(this, "Error receiving flight details", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        String details = "Flight " + flightNumber + "\nFrom: " + from + "\nTo: " + to + "\nDate: " + date + "\nPrice: " + price;
        flightDetailsTextView.setText(details);

        bookFlightButton.setOnClickListener(v -> bookFlight());
    }


    private void bookFlight() {
        String userEmail = getIntent().getStringExtra("userEmail").replace(".", ",");
        if (userEmail == null) {
            Toast.makeText(this, "User email not found", Toast.LENGTH_SHORT).show();
            return;
        }

        Map<String, String> booking = new HashMap<>();
        booking.put("flightNumber", flightNumber);
        booking.put("from", from);
        booking.put("to", to);
        booking.put("date", date);
        booking.put("price", price);

        DatabaseReference bookingsRef = FirebaseDatabase.getInstance().getReference("bookings");
        String bookingId = bookingsRef.child(userEmail).push().getKey();
        if (bookingId != null) {
            bookingsRef.child(userEmail).child(bookingId).setValue(booking)
                    .addOnSuccessListener(aVoid -> Toast.makeText(this, "Flight booked successfully", Toast.LENGTH_SHORT).show())
                    .addOnFailureListener(e -> Toast.makeText(this, "Failed to book flight", Toast.LENGTH_SHORT).show());
        }
    }

}*/

package com.example.myapplication;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.HashMap;
import java.util.Map;

public class FlightDetailsActivity extends AppCompatActivity {

    private TextView flightDetailsTextView;
    private Button bookFlightButton;
    private DatabaseReference dbRef;
    private String flightNumber, from, to, date, price, boardingTime, deboardingTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flight_details);

        flightDetailsTextView = findViewById(R.id.flightDetailsTextView);
        bookFlightButton = findViewById(R.id.bookFlightButton);

        dbRef = FirebaseDatabase.getInstance().getReference("bookings");

        flightNumber = getIntent().getStringExtra("flightNumber");
        from = getIntent().getStringExtra("from");
        to = getIntent().getStringExtra("to");
        date = getIntent().getStringExtra("date");
        price = getIntent().getStringExtra("price");
        boardingTime = getIntent().getStringExtra("boardingTime");
        deboardingTime = getIntent().getStringExtra("deboardingTime");

        String details = "Flight " + flightNumber + "\nFrom: " + from + "\nTo: " + to +
                "\nDate: " + date + "\nPrice: " + price +
                "\nBoarding Time: " + boardingTime + "\nDeboarding Time: " + deboardingTime;
        flightDetailsTextView.setText(details);

        bookFlightButton.setOnClickListener(v -> bookFlight());
    }

    private void bookFlight() {
        String userEmail = getIntent().getStringExtra("userEmail").replace(".", ",");
        if (userEmail == null) {
            Toast.makeText(this, "User email not found", Toast.LENGTH_SHORT).show();
            return;
        }

        Map<String, String> booking = new HashMap<>();
        booking.put("flightNumber", flightNumber);
        booking.put("from", from);
        booking.put("to", to);
        booking.put("date", date);
        booking.put("price", price);
        booking.put("boardingTime", boardingTime);
        booking.put("deboardingTime", deboardingTime);

        DatabaseReference bookingsRef = FirebaseDatabase.getInstance().getReference("bookings");
        String bookingId = bookingsRef.child(userEmail).push().getKey();
        if (bookingId != null) {
            bookingsRef.child(userEmail).child(bookingId).setValue(booking)
                    .addOnSuccessListener(aVoid -> Toast.makeText(this, "Flight booked successfully", Toast.LENGTH_SHORT).show())
                    .addOnFailureListener(e -> Toast.makeText(this, "Failed to book flight", Toast.LENGTH_SHORT).show());
        }
    }
}

