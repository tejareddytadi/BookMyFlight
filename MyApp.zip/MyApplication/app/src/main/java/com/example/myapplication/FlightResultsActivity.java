package com.example.myapplication;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class FlightResultsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flight_results);

        ListView flightResultsListView = findViewById(R.id.flightResultsListView);

        // Mock data for flight results
        ArrayList<String> flightList = new ArrayList<>();
        flightList.add("Flight 101: From A to B - $150");
        flightList.add("Flight 202: From A to C - $200");
        flightList.add("Flight 303: From B to D - $180");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, flightList);
        flightResultsListView.setAdapter(adapter);
    }
}
