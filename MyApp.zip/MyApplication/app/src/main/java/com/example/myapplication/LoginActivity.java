package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginActivity extends AppCompatActivity {

    private EditText emailEditText, passwordEditText;
    private DatabaseReference dbRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        Button loginSubmitButton = findViewById(R.id.loginSubmitButton);

        dbRef = FirebaseDatabase.getInstance().getReference("users");

        // Login button click listener
        loginSubmitButton.setOnClickListener(v -> loginUser());
    }

    private void loginUser() {
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if the user is admin
        if (email.equals("admin@gmail.com") && password.equals("admin")) {
            Toast.makeText(this, "Admin login successful", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(LoginActivity.this, AdminActivity.class));
            finish();
        } else {
            // Handle regular user login and pass the user's email to SearchFlightsActivity
            dbRef.get().addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    boolean userFound = false;
                    for (DataSnapshot snapshot : task.getResult().getChildren()) {
                        User user = snapshot.getValue(User.class);
                        if (user != null && user.email.equals(email) && user.password.equals(password)) {
                            userFound = true;
                            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
                            // Pass the user email to SearchFlightsActivity
                            Intent intent = new Intent(LoginActivity.this, SearchFlightsActivity.class);
                            intent.putExtra("userEmail", email);
                            startActivity(intent);
                            finish();
                            break;
                        }
                    }
                    if (!userFound) {
                        Toast.makeText(this, "Invalid email or password", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "Failed to connect to Firebase", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
