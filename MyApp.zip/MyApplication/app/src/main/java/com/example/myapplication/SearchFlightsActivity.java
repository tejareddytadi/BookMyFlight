package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.Calendar;

public class SearchFlightsActivity extends AppCompatActivity {

    private EditText fromEditText, toEditText, dateEditText;
    private ListView flightResultsListView;
    private DatabaseReference dbRef;
    private ArrayList<String> flightList;
    private ArrayList<Flight> flightData;
    private static final String TAG = "SearchFlightsActivity";
    private String userEmail;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_flights);

        // Initialize UI components
        fromEditText = findViewById(R.id.fromEditText);
        toEditText = findViewById(R.id.toEditText);
        dateEditText = findViewById(R.id.dateEditText);
        Button searchFlightsButton = findViewById(R.id.searchFlightsButton);
        Button viewBookingsButton = findViewById(R.id.viewBookingsButton);
        flightResultsListView = findViewById(R.id.flightResultsListView);

        dbRef = FirebaseDatabase.getInstance().getReference("flights");
        flightList = new ArrayList<>();
        flightData = new ArrayList<>();

        // Get the user email passed from the previous activity
        userEmail = getIntent().getStringExtra("userEmail");
        if (userEmail == null || userEmail.isEmpty()) {
            Toast.makeText(this, "User email not found. Please log in again.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Replace "." with "," for Firebase key format
        userEmail = userEmail.replace(".", ",");

        // Set a click listener for the dateEditText to show a DatePickerDialog
        dateEditText.setOnClickListener(v -> showDatePicker());

        // Search Flights button click listener
        searchFlightsButton.setOnClickListener(v -> searchFlights());

        // View Bookings button click listener
        viewBookingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(SearchFlightsActivity.this, ViewBookingsActivity.class);
            intent.putExtra("userEmail", userEmail);
            startActivity(intent);
        });

        // ListView item click listener to navigate to FlightDetailsActivity
        flightResultsListView.setOnItemClickListener((parent, view, position, id) -> {
            Flight selectedFlight = flightData.get(position);
            Log.d(TAG, "Selected flight: " + selectedFlight.flightNumber);
            Intent intent = new Intent(SearchFlightsActivity.this, FlightDetailsActivity.class);
            intent.putExtra("flightNumber", selectedFlight.flightNumber);
            intent.putExtra("from", selectedFlight.from);
            intent.putExtra("to", selectedFlight.to);
            intent.putExtra("date", selectedFlight.date);
            intent.putExtra("price", selectedFlight.price);
            intent.putExtra("boardingTime", selectedFlight.boardingTime);
            intent.putExtra("deboardingTime", selectedFlight.deboardingTime);
            intent.putExtra("userEmail", userEmail);
            startActivity(intent);
        });
    }

    private void showDatePicker() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    @SuppressLint("DefaultLocale") String date = String.format("%04d-%02d-%02d", selectedYear, selectedMonth + 1, selectedDay);
                    dateEditText.setText(date);
                },
                year, month, day
        );

        datePickerDialog.show();
    }

    private void searchFlights() {
        String from = fromEditText.getText().toString().trim();
        String to = toEditText.getText().toString().trim();
        String date = dateEditText.getText().toString().trim();

        if (from.isEmpty() || to.isEmpty() || date.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        Log.d(TAG, "Searching flights from: " + from + ", to: " + to + ", on date: " + date);

        dbRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                flightList.clear();
                flightData.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Flight flight = snapshot.getValue(Flight.class);
                    if (flight != null && flight.from.equalsIgnoreCase(from) &&
                            flight.to.equalsIgnoreCase(to) && flight.date.equals(date)) {

                        String result = "Flight " + flight.flightNumber + ": " + flight.from + " to " + flight.to + " on " + flight.date + " - " + flight.price +
                                "\nBoarding Time: " + flight.boardingTime + ", Deboarding Time: " + flight.deboardingTime;
                        flightList.add(result);
                        flightData.add(flight);
                    }
                }

                if (flightList.isEmpty()) {
                    Toast.makeText(SearchFlightsActivity.this, "No flights found", Toast.LENGTH_SHORT).show();
                } else {
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(SearchFlightsActivity.this,
                            android.R.layout.simple_list_item_1, flightList);
                    flightResultsListView.setAdapter(adapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "Database error: " + databaseError.getMessage());
                Toast.makeText(SearchFlightsActivity.this, "Failed to retrieve flights", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
