package com.example.myapplication;

public class User {
    public String email;
    public String name;
    public String dob;
    public String password;

    public User() {
        // Default constructor required for Firebase
    }

    public User(String email, String name, String dob, String password) {
        this.email = email;
        this.name = name;
        this.dob = dob;
        this.password = password;
    }
}
