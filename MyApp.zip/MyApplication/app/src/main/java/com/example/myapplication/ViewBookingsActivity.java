package com.example.myapplication;

import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;

public class ViewBookingsActivity extends AppCompatActivity {

    private ListView bookingsListView;
    private DatabaseReference dbRef;
    private ArrayList<String> bookingsList;
    private static final String TAG = "ViewBookingsActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_bookings);

        bookingsListView = findViewById(R.id.bookingsListView);
        dbRef = FirebaseDatabase.getInstance().getReference("bookings");
        bookingsList = new ArrayList<>();

        String userEmail = getIntent().getStringExtra("userEmail");
        if (userEmail == null || userEmail.isEmpty()) {
            Toast.makeText(this, "User email not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        loadUserBookings(userEmail);
    }

    private void loadUserBookings(String email) {
        dbRef.child(email).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                bookingsList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String flightNumber = snapshot.child("flightNumber").getValue(String.class);
                    String from = snapshot.child("from").getValue(String.class);
                    String to = snapshot.child("to").getValue(String.class);
                    String date = snapshot.child("date").getValue(String.class);
                    String price = snapshot.child("price").getValue(String.class);
                    String boardingTime = snapshot.child("boardingTime").getValue(String.class);
                    String deboardingTime = snapshot.child("deboardingTime").getValue(String.class);

                    String bookingDetails = "Flight " + flightNumber + "\nFrom: " + from +
                            "\nTo: " + to + "\nDate: " + date + "\nPrice: " + price +
                            "\nBoarding Time: " + boardingTime + "\nDeboarding Time: " + deboardingTime;
                    bookingsList.add(bookingDetails);
                }

                if (bookingsList.isEmpty()) {
                    Toast.makeText(ViewBookingsActivity.this, "No bookings found", Toast.LENGTH_SHORT).show();
                } else {
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(ViewBookingsActivity.this,
                            android.R.layout.simple_list_item_1, bookingsList);
                    bookingsListView.setAdapter(adapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Database error: " + error.getMessage());
                Toast.makeText(ViewBookingsActivity.this, "Failed to load bookings", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
